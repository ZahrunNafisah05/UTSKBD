<?php
require_once("auth.php");
require_once("config.php");

$id = $_GET['id'];
$user_id = $_SESSION['user']['id'];

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $content = trim($_POST['content']);

    $query = "UPDATE posts SET content = '$content' WHERE id = $id AND user_id = $user_id";
    $result = mysqli_query($conn, $query);

    if ($result) {
        header("Location: timeline.php");
        exit;
    } else {
        die("Gagal update: " . mysqli_error($conn));
    }
}

$query = mysqli_query($conn, "SELECT * FROM posts WHERE id = $id AND user_id = $user_id");
$post = mysqli_fetch_assoc($query);

if (!$post) {
    die("Post tidak ditemukan atau tidak punya akses.");
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Postingan</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
</head>
<body class="bg-light">
<div class="container mt-5">
    <h3>Edit Postingan</h3>
    <form method="post">
        <div class="form-group">
            <textarea name="content" class="form-control" required><?php echo htmlspecialchars($post['content']); ?></textarea>
        </div>
        <button type="submit" class="btn btn-success mt-2">Simpan</button>
        <a href="timeline.php" class="btn btn-secondary mt-2">Batal</a>
    </form>
</div>
</body>
</html>
