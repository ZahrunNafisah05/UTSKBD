<?php
require_once("auth.php");
require_once("config.php");

$user_id = $_SESSION['user']['id'];
$query = mysqli_query($conn, "SELECT * FROM posts WHERE user_id = $user_id ORDER BY created_at DESC");
?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Dashboard</title>

    <link rel="stylesheet" href="css/bootstrap.min.css" />
</head>

<body class="bg-light" style="background: url('img/latar.jpg') no-repeat center center fixed; background-size: cover;">



    <div class="container mt-5">
        <div class="row">
            <div class="col-md-4">

                <div class="card" style="background-color: rgba(204, 220, 164, 0.5);">
                    <div class="card-body text-center">

                        <img class="img img-responsive rounded-circle mb-3" width="160" src="img/profil.jpg" />

                        <h3><?php echo $_SESSION["user"]["name"] ?></h3>
                        <p><?php echo $_SESSION["user"]["email"] ?></p>
                        <a href="edit.php">Edit Profil</a> | <a href="delete.php"
                            onclick="return confirm('Apakah Anda yakin ingin menghapus akun?');">Hapus Akun</a>
                        <p><a href="logout.php">Logout</a></p>
                    </div>
                </div>
            </div>


            <div class="col-md-8">

                <form action="create_post.php" method="post">
                    <div class="form-group">
                        <textarea class="form-control mb-3" name="content" placeholder="Apa yang kamu pikirkan?"
                            required></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary mb-5">Post</button>
                </form>


                <?php while ($row = mysqli_fetch_assoc($query)) { ?>
                    <div class="card mb-3">
                        <div class="card-body">
                            <?php echo htmlspecialchars($row['content']); ?>
                            <div class="mt-2">
                                <a href="edit_post.php?id=<?php echo $row['id']; ?>" class="btn btn-sm btn-warning">Edit</a>
                                <a href="delete_post.php?id=<?php echo $row['id']; ?>" class="btn btn-sm btn-danger"
                                    onclick="return confirm('Yakin mau hapus?')">Hapus</a>
                            </div>
                        </div>
                    </div>
                <?php } ?>

            </div>

        </div>
    </div>

</body>

</html>