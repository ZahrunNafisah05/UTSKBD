<?php
require_once("auth.php");
require_once("config.php"); 

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $user_id = $_SESSION['user']['id'];
    $content = trim($_POST['content']);

    if (!empty($content)) {
        $query = "INSERT INTO posts (user_id, content, created_at) VALUES ('$user_id', '$content', NOW())";
        $result = mysqli_query($conn, $query);

        if (!$result) {
            die("Gagal menyimpan postingan: " . mysqli_error($conn));
        }
    }

    header("Location: timeline.php");
    exit;
}
?>
