<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
session_start();
require_once 'config.php';

if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user']['id'];

try {
    $stmt = mysqli_prepare($conn, "DELETE FROM users WHERE id = ?");
    
    if ($stmt) {
        mysqli_stmt_bind_param($stmt, "i", $user_id);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
        
        session_destroy();

        header("Location: login.php");
        exit();
    } else {
        throw new Exception("Gagal mempersiapkan query.");
    }
} catch (Exception $e) {
    echo "Terjadi kesalahan: " . $e->getMessage();
}
