<?php
require_once("auth.php");
require_once("config.php");

$id = $_GET['id'];
$user_id = $_SESSION['user']['id'];

$query = "DELETE FROM posts WHERE id = $id AND user_id = $user_id";
$result = mysqli_query($conn, $query);

if (!$result) {
    die("Gagal menghapus postingan: " . mysqli_error($conn));
}

header("Location: timeline.php");
exit;
?>
