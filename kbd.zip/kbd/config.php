<?php

$db_host = "localhost";
$db_user = "nafisah";
$db_pass = "nafisah665";
$db_name = "kbd";


$conn = mysqli_connect($db_host, $db_user, $db_pass, $db_name);